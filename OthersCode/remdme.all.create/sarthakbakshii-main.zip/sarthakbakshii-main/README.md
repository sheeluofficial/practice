

<!--
**sarthakbakshii/sarthakbakshii** is a ✨ _special_ ✨ repository because its `README.md` (this file) appears on your GitHub profile.

Here are some ideas to get you started:

- 🔭 I’m currently working on ...
- 🌱 I’m currently learning ...
- 👯 I’m looking to collaborate on ...
- 🤔 I’m looking for help with ...
- 💬 Ask me about ...
- 📫 How to reach me: ...
- 😄 Pronouns: ...
- ⚡ Fun fact: ...
-->
<h1 align="center">Hi <img src="https://media.giphy.com/media/hvRJCLFzcasrR4ia7z/giphy.gif" width="30px">, I'm Sarthak Bakshi 👨🏻‍💻</h1>
<h3 align="center">I'm a Full-Stack Web Developer with hands-on experience in designing, developing, and implementing
        applications and solutions using JavaScript, ReactJS.</h3>

<p align="center"> <img
                src="https://komarev.com/ghpvc/?username=vaibhav-raj&label=Profile%20views&color=0e75b6&style=flat"
                alt="vaibhav-raj" /> </p>
                
<!-- <p align="center"> <img
                src="https://user-images.githubusercontent.com/40136017/134124139-172a975d-1cf3-4538-8049-8efab00e4489.png"
                alt="vaibhav-raj" /> </p> -->

- 🌱 I’m currently learning **MERN FULL STACK DEVELOPEMNT** 
- 🔭 Previously i was working as a **LAMP FULL STACK DEVELOPEMNT**
- 🌱 &nbsp; Learning more about AWS, MongoDB, Python and Typscript.
- 👯‍♂️ &nbsp;&nbsp;I’m looking to collaborate on MERN Stack projects and lot of learnings. Happy to Contribute in Opne source Projects<br>
- 💬 &nbsp;&nbsp;Ask me about anything related to MERN stack and data structure & algorithms.I will be happy to tell, if I am unable then surely we will together learn new things.
- ⚡ Fun fact: Coder with biceps.:smile:

- 📫 How to reach me **sarthakbakshi@gmail.com**

<!-- - 🔗 Personal Website **https://vaibhavraj.netlify.app/** -->

<!-- ### Feel Free to Contact me..... -->
<h3 align="center">Feel Free to Contact me.....</h3>
<p align="center">
        <a href="https://github.com/sarthakbakshii"><img alt="github" width="10%" style="padding:5px"
                        src="https://img.icons8.com/clouds/100/000000/github.png" /></a>
        <a href="https://www.linkedin.com/in/sarthak-bakshi/"><img alt="linkedin" width="10%" style="padding:5px"
                        src="https://img.icons8.com/clouds/100/000000/linkedin.png" /></a>
        <a href="https://twitter.com/sarthakbakshii"><img alt="twitter" width="10%" style="padding:5px"
                        src="https://img.icons8.com/clouds/100/000000/twitter.png" /></a>
</p>
<h3 align="center">Languages and Tools:</h3>
<p align="center " style="border: 1px solid black" > 
                <a href="https://www.cprogramming.com/" target="_blank"> 
                        <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/c/c-original.svg" alt="c" width="40" height="40" /> 
                </a> 
                <a href="https://git-scm.com/" target="_blank"> <img
                        src="https://www.vectorlogo.zone/logos/git-scm/git-scm-icon.svg" alt="git" width="40"
                        height="40" /> </a> <a href="https://www.w3.org/html/" target="_blank"> <img
                        src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original-wordmark.svg"
                        alt="html5" width="40" height="40" /> </a> <a
                href="https://developer.mozilla.org/en-US/docs/Web/JavaScript" target="_blank"> <img
                        src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-original.svg"
                        alt="javascript" width="40" height="40" /> </a> <a href="https://postman.com" target="_blank">
                <img src="https://www.vectorlogo.zone/logos/getpostman/getpostman-icon.svg" alt="postman" width="40"
                        height="40" /> </a> <a href="https://reactjs.org/" target="_blank"> <img
                        src="https://raw.githubusercontent.com/devicons/devicon/master/icons/react/react-original-wordmark.svg"
                        alt="react" width="40" height="40" /> </a><img
                src="https://raw.githubusercontent.com/devicons/devicon/master/icons/express/express-original-wordmark.svg"
                alt="express" width="40" height="40" /> </a> <a href="https://www.mongodb.com/" target="_blank"> <img
                        src="https://raw.githubusercontent.com/devicons/devicon/master/icons/mongodb/mongodb-original-wordmark.svg"
                        alt="mongodb" width="40" height="40" /> </a> <a href="https://nodejs.org" target="_blank"> <img
                        src="https://raw.githubusercontent.com/devicons/devicon/master/icons/nodejs/nodejs-original-wordmark.svg"
                        alt="nodejs" width="40" height="40" /> </a> <a href="https://reactjs.org/" target="_blank"> <img
                        src="https://raw.githubusercontent.com/devicons/devicon/master/icons/react/react-original-wordmark.svg"
                        alt="react" width="40" height="40" /> </a> <a href="https://redux.js.org" target="_blank"> <img
                        src="https://raw.githubusercontent.com/devicons/devicon/master/icons/redux/redux-original.svg"
                        alt="redux" width="40" height="40" /> </a> </p>

<p align="center" ><img  
                src="https://github-readme-stats.vercel.app/api/top-langs?username=sarthakbakshii&theme=dark&hide_border=true&show_icons=true&locale=en&layout=compact"
                alt="sarthakbakshii" />  </p>

<p align="center "  >
                <img  width="48%"
                src="https://github-readme-stats.vercel.app/api?username=sarthakbakshii&show_icons=true&theme=dark&hide_border=true&locale=en"
                alt="sarthakbakshii" />  &nbsp; &nbsp; 
        <img width="48%" src="https://github-readme-streak-stats.herokuapp.com/?user=sarthakbakshii&theme=dark&hide_border=true"
                alt="sarthakbakshii" /></p>

### 📈 GitHub Activity:
  <a href="https://github.com/sarthakbakshii/github-readme-activity-graph"><img alt="sarthakbakshii's Activity Graph" src="https://activity-graph.herokuapp.com/graph?username=sarthakbakshii&bg_color=1F222E&color=F8D866&line=F85D7F&point=FFFFFF&hide_border=true" /></a>
  


